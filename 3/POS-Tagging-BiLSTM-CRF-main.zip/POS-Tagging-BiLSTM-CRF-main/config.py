train_portion = 0.84
embedding_dim = 100
max_length = 141
batch_size = 256
num_epochs = 3


