from pycantonese.pos_tagging.hkcancor_to_ud import hkcancor_to_ud
from pycantonese.pos_tagging.tagger import POSTagger


__all__ = ["POSTagger", "hkcancor_to_ud"]
