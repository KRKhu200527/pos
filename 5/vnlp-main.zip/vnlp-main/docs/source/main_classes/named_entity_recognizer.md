Named Entity Recognizer
----------

.. automodule:: vnlp.named_entity_recognizer.named_entity_recognizer
    :members:

SentencePiece Unigram Context Named Entity Recognizer
===================================
.. automodule:: vnlp.named_entity_recognizer.spu_context_ner
    :members:

CharNER
===================================
.. automodule:: vnlp.named_entity_recognizer.charner
    :members: