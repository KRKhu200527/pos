Part of Speech Tagger
----------

.. automodule:: vnlp.part_of_speech_tagger.part_of_speech_tagger
    :members:

SentencePiece Unigram Context Part of Speech Tagger
===================================
.. automodule:: vnlp.part_of_speech_tagger.spu_context_pos
    :members:

Tree-stack Part of Speech Tagger
===================================
.. automodule:: vnlp.part_of_speech_tagger.treestack_pos
    :members: