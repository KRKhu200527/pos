Sentiment Analyzer
----------

.. automodule:: vnlp.sentiment_analyzer.sentiment_analyzer
    :members:

SentencePiece Unigram Context BiGRU Sentiment Analyzer
===================================
.. automodule:: vnlp.sentiment_analyzer.spu_context_bigru_sentiment
    :members: