from .named_entity_recognizer import NamedEntityRecognizer

__all__ = ["NamedEntityRecognizer"]
