from .stemmer_morph_analyzer import StemmerAnalyzer

__all__ = ["StemmerAnalyzer"]
