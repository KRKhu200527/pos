from .part_of_speech_tagger import PoSTagger

__all__ = ["PoSTagger"]
