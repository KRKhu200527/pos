from .sentence_splitter import SentenceSplitter

__all__ = ["SentenceSplitter"]
