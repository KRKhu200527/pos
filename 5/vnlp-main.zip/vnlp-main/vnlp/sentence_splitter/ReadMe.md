#### Sentence Splitter

This is an adapted version of Koehn and Schroeder's Sentence Splitter found in https://pypi.org/project/sentence-splitter/

I reduced the code for Turkish language and expanded the abbreviations lexicon.