from .dependency_parser import DependencyParser

__all__ = ["DependencyParser"]
