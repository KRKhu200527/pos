# Release TODO
- change version number

- >> make clean
- >> make lint
- >> make doc
- >> make tox
- >> make tox-report

- merge to master branch
- >> make clean
- >> make upload

# Requirements
Make sure test/requirements.txt matches setup.py.
