from ._human import *
from ._pronoun import *
from ._self import *
