# 人選|candidate

CANDIDATE_WORDS = {
    '人選',
    '候選人',
    '應選人',
    '被選人',
}
