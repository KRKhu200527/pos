# 得主|recipient

RECIPIENT_WORDS = {
    '得主',
    '得獎人',
}
