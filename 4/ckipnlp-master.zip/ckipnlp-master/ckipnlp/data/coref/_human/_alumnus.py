# 校友|alumnus

ALUMNUS_WORDS = {
    '校友',
}
